package state;
import outputpro.op;
public class s1 extends s
{
	@Override
    public void Start()
    {
     op.payMsg();
    }
}
