package state;
import outputpro.op;
public class s0 extends s
{
	@Override
    public void Activate()
    {
    	System.out.println("\n \n The Gas pump is  Activated ");
    	op.storeData();
    }
}

