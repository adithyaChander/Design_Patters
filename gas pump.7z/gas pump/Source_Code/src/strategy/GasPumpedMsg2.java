package strategy;
public class GasPumpedMsg2 extends GasPumpedMsg
{
    public void gasPumpedMsg()
    {
    	float l = dobj.getL();
    	System.out.printf("The Gas pump has sucessfully pumped L  units:"+l);
      
    }
    
}
