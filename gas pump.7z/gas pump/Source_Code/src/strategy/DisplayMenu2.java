package strategy;

public class DisplayMenu2 extends DisplayMenu
{
    public void displayMenu()
    {
    System.out.println("\n ***********DISPLAY MENU*************");
   	 System.out.println("\n Select option 4 for Premium Fuel ");
   	 System.out.println("\n Select option 5 to Regular Fuel");
   	 System.out.println("\n Select option 6 to Start the Pump");

    }
    
}