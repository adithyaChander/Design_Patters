package strategy;
public class PayMsg1 extends PayMsg
{
    public void payMsg()
    {
      
   	 System.out.println("Please select a payment mode from the list of available options below");
   	 
    }
    
}
