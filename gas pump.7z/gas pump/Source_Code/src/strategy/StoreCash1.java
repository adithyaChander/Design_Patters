package strategy;
public class StoreCash1 extends StoreCash
{
    public void storeCash()
    {
        int c =dobj.getintc();
        float d =(float)c;
        dobj.setcash(d);
    }
    
}

