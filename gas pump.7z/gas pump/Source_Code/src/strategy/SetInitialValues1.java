package strategy;
public class SetInitialValues1 extends SetInitialValues
{
	public void setInitialValues()
    {
      
        dobj.setG(0);
        dobj.settotal(0);
    }
    
}
