package strategy;
public class DisplayMenu1 extends DisplayMenu
{
    public void displayMenu()
    {
    System.out.println("\n ***********DISPLAY MENU*************");
   	System.out.println("\n Select option 7 to start the pump ");
   	System.out.println("\n Select option 8 to Pump in Gallon");
   	System.out.println("\n Select option 9 to Stop the Pump");
    }
}
