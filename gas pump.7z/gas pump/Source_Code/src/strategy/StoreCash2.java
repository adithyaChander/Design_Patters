package strategy;

public class StoreCash2 extends StoreCash
{
    public void storeCash()
    {
        
        float c =dobj.getfloatc();
        
        dobj.setcash(c);
     
    }
    
}