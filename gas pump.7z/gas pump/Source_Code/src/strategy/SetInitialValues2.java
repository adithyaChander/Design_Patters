package strategy;
public class SetInitialValues2 extends SetInitialValues
{
	
	public void setInitialValues()
    {
      
        dobj.setL(0);
        dobj.settotal(0);
    }
    
}