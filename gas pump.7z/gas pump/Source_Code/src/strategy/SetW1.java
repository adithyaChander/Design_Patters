package strategy;
public class SetW1 extends SetW
{
	public void setW(int w)
    {
      dobj.setintW(w);
    }
    
}

