package strategy;
public class CancelMsg1 extends CancelMsg 
{
    public void cancelMsg()
    {      
    	 System.out.println("\n The operation has been cancelled \n");
    }
    
}
