package strategy;

public class StopMsg1 extends StopMsg
{
    public void stopMsg()
    {
      
   	 System.out.println("The Gas Pump has stopped Pumping");
   	 System.out.println("\n Choose to print the Receipt ");
   	 
    }
    
}

