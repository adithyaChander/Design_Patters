package strategy;
public class NoReceipt1 extends NoReceipt
{
    public void noReceipt()
    {
      
    }
}