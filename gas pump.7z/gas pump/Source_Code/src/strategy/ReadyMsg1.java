package strategy;

public class ReadyMsg1 extends ReadyMsg
{
    public void readyMsg()
    {
      
    	System.out.println(" \n The Gas Pump is ready to pump; Continue to Pump..");
    }
    
}
