package strategy;
public class SetPrice1 extends SetPrice
{
	@Override
    public void setPrice(int g)
    {
		
    }
}
