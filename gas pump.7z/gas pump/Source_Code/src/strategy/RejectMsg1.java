package strategy;

public class RejectMsg1 extends RejectMsg
{
    public void rejectMsg()
    {
   	 System.out.println("Sorry the action is Rejected.Choose an option.....");
    }
    
}
