package datastore;

public class data3 extends data
{
	static float temp_a;
	static float temp_b;
	static float temp_c;
	static float L;
	static float reg1_price;
	static float pre_price;
	static float cash;
	static float total;
	static float price;
	public float getprice()
	{
		  return price;
	}
	 public void setprice(float y)
	{
			price=y;
	}
	 public void setfloata(float a)
	{
		temp_a =a;
	}
	public void setfloatb(float b)
	{
		temp_b=b;
	}
	public float getfloatb()
	{
		return temp_b;
	}
	public float getfloata()
	{
		return temp_a;
	}
	public void setfloatc(float a)
	{
		 temp_c =a;
	}
	public float getfloatc()
	{
		  return temp_c;
	}
	public void setL(float a)
	{
		    L=a;
	}
	public float getL()
	{
		   return L;
	}
	 public void setpre_price(float a)
	{
			pre_price=a;
	}
	public float getpre_price()
	{
		  return pre_price;
	}
	public void setreg1_price(float a)
	{
			reg1_price=a;
	}
	public float getreg1_price()
	{
		  return reg1_price;
	}
	public void setcash(float a)
	{
			cash=a;
	}
	public float getcash()
	{
		return cash;
	}
	public float gettotal()
	{
		return total;
	}
	public void settotal(float a)
	{
			total=a;
	}
	
}	
	
	
	
