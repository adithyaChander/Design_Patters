package datastore;

public abstract class data
{
		 public  void setinta(int a)
		 {
			 
		 }
		 public  void setintc(int a)
		 {
			 
		 }
		 public void setfloatc(float c)
		 {
			 
		 }
		 public float getfloatc()
		 {
			 return 0;
		 }
		 
		 public  void setintW(int a)
		 {
			 
		 }
		 public  int getintW()
		 {
			 return 0;
		 }
		 public int getinta()
		 {
			 return 0;
		 }
		 public  int getintc()
		 {
			 return 0;
		 }
		 public  void setprice(float a)
		 {
			 
		 }
		 public  void setcash(float a)
		 {
			 
		 }
		 public  void setG(float a)
		 {
			 
		 }
		 public  float getprice()
		 {
			 return 0;
		 }
		 public  float getcash()
		 {
			 return 0;
		 }
		 public  float getG()
		 {
			 return 0;
		 }
		 
		 public float gettotal()
		 {
			 return 0;
		 }
		 public  void settotal(float a)
		 {
			 
		 }
		  public  void setfloata(float a)
		 {
			 
		 }
		 public  void setfloatb(float a)
		 {
			 
		 }
		 public  float getfloata()
		 {
			 return 0;
		 }
		 public float getfloatb()
		 {
			 return 0;
		 }
		 public void setsup_price(float a)
		{
				
		}
		 public float getsup_price()
		{
			  return 0;
		}
		public void setreg_price(float a)
		{
				
		}
		public float getreg_price()
		{
			  return 0;
		}
		 
		
		
		public void setpre_price(float a)
		{
				
		}
		public void setreg1_price(float a)
		{
				
		}
		public float getreg1_price()
		{
		    	return 0;
		}
		public float getpre_price()
		{
		    	return 0;
		}
		public float getL()
		{
		    	return 0;
		}
		public void setL(float a)
		{
		    	
		}
		 
		 
}
